# flutter-firebase
All course files for the Flutter &amp; Firebase tutorial playlist on The Net Ninja YouTube channel

## how to use this repo
Each lesson in the playlist has it's own code in it's own branch. To see the code for lesson 7, for example, you would select the lesson-7 branch.
